<script type="text/javascript">

  if ( window.history.replaceState ) {
      window.history.replaceState( null, null, window.location.href );
  }
</script>




<?php

if (isset($_POST['submit'])) {

    $db = mysqli_connect('localhost', 'root', 'root', 'memory');

  	$a2 = $_POST['As'];

  	$a3 = $_POST['username'];

    $a4 = $_POST['email'];

    $a5 = $_POST['password1'];

    $a6 = $_POST['password2'];

    $a8 = $_POST['gender'];

    $a9 = $_POST['company'];

    $a10 = $_POST['catagory'];

    $a11 = $_POST['number'];

    $a12 = $_POST['location'];





    $query = "INSERT INTO addcars(a2,a3,a4,a5,a6,a8,a9,a10,a11,a12)
      	    	  VALUES ('$a2', '$a3', '$a4', '$a5', '$a6', '$a8', '$a9', '$a10', '$a11', '$a12')";
           $results = mysqli_query($db, $query);
           
               $message = "values have been entered";

           
           echo "<script type='text/javascript'>alert('$message');</script>";
    }



?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
      <style>
      div {
    background-color: lightgreen;
    }
    </style>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!--- Include the above in your HEAD tag ---------->

<div class="container">

    <div id="signupbox" style=" margin-top:50px" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
        <div class="panel panel-info">
            <div class="panel-heading">
                <div class="panel-title">ADDCARS</div>
                <!-- <div style="float:right; font-size: 85%; position: relative; top:-10px"><a id="signinlink" href="/accounts/login/">Sign In</a></div> -->
            </div>
            <div class="panel-body" >
                <form method="post" action="">
                    <input type='hidden' name='csrfmiddlewaretoken' value='XFe2rTYl9WOpV8U6X5CfbIuOZOELJ97S' />


                    <form  class="form-horizontal" method="post" >
                        <input type='hidden' name='csrfmiddlewaretoken' value='XFe2rTYl9WOpV8U6X5CfbIuOZOELJ97S' />
                        
                        <div id="div_id_As" class="form-group required">
                            <label for="id_As"  class="control-label col-md-4  requiredField">Ownership<span class="asteriskField">*</span> </label>
                            <div class="controls col-md-8 "  style="margin-bottom: 10px">
                                <label class="radio-inline"> <input type="radio" checked="checked" name="As" id="id_As_1" value="I"  style="margin-bottom: 10px">Individual </label>
                                <label class="radio-inline"> <input type="radio" name="As" id="id_As_2" value="CI"  style="margin-bottom: 10px">Company/Institute </label>
                            </div>
                        </div>
                        <div id="div_id_username" class="form-group required">
                            <label for="id_username" class="control-label col-md-4  requiredField">CarName<span class="asteriskField">*</span> </label>
                            <div class="controls col-md-8 ">
                                <input class="input-md  textinput textInput form-control" id="id_username" maxlength="30" name="username" placeholder="Enter Car Name" style="margin-bottom: 10px" type="text" required/>
                            </div>
                        </div>
                        <div id="div_id_email" class="form-group required">
                            <label for="id_email" class="control-label col-md-4  requiredField">Carmodel<span class="asteriskField">*</span> </label>
                            <div class="controls col-md-8 ">
                                <input class="input-md emailinput form-control" id="id_email" name="email" placeholder="Model Name" style="margin-bottom: 10px" type="text"required />
                            </div>
                        </div>
                        <div id="div_id_password1" class="form-group required">
                            <label for="id_password1" class="control-label col-md-4  requiredField">Manufacturer<span class="asteriskField">*</span> </label>
                            <div class="controls col-md-8 ">
                                <input class="input-md textinput textInput form-control" id="id_password1" name="password1" placeholder="Manufacturer" style="margin-bottom: 10px" type="text"required />
                            </div>
                        </div>
                        <div id="div_id_password2" class="form-group required">
                             <label for="id_password2" class="control-label col-md-4  requiredField">Price<span class="asteriskField">*</span> </label>
                             <div class="controls col-md-8 ">
                                <input class="input-md textinput textInput form-control" id="id_password2" name="password2" placeholder="price" style="margin-bottom: 10px" type="text" required/>
                            </div>
                        </div>
                        
                        <div id="div_id_gender" class="form-group required">
                            <label for="id_gender"  class="control-label col-md-4  requiredField">EngineType<span class="asteriskField">*</span> </label>
                            <div class="controls col-md-8 "  style="margin-bottom: 10px">
                                 <label class="radio-inline"> <input type="radio" name="gender" checked="checked" id="id_gender_1" value="Pertol"  style="margin-bottom: 10px">Petrol</label>
                                 <label class="radio-inline"> <input type="radio" name="gender" id="id_gender_2" value="Deisel"  style="margin-bottom: 10px">Desiel</label>
                            </div>
                        </div>
                        <div id="div_id_company" class="form-group required">
                            <label for="id_company" class="control-label col-md-4  requiredField">Geartype<span class="asteriskField">*</span> </label>
                            <div class="controls col-md-8 ">
                                 <input class="input-md textinput textInput form-control" id="id_company" name="company" placeholder="Enter Gear Type" style="margin-bottom: 10px" type="text"required />
                            </div>
                        </div>
                        <div id="div_id_catagory" class="form-group required">
                            <label for="id_catagory" class="control-label col-md-4  requiredField">HorsePower<span class="asteriskField">*</span> </label>
                            <div class="controls col-md-8 ">
                                 <input class="input-md textinput textInput form-control" id="id_catagory" name="catagory" placeholder="Horsepower" style="margin-bottom: 10px" type="text" required/>
                            </div>
                        </div>
                        <div id="div_id_number" class="form-group required">
                             <label for="id_number" class="control-label col-md-4  requiredField">FuelCapacity<span class="asteriskField">*</span> </label>
                             <div class="controls col-md-8 ">
                                 <input class="input-md textinput textInput form-control" id="id_number" name="number" placeholder="Fuelcapacity" style="margin-bottom: 10px" type="text"required />
                            </div>
                        </div>
                        <div id="div_id_location" class="form-group required">
                            <label for="id_location" class="control-label col-md-4  requiredField">Acessories<span class="asteriskField">*</span> </label>
                            <div class="controls col-md-8 ">
                                <input class="input-md textinput textInput form-control" id="id_location" name="location" placeholder="Accessories" style="margin-bottom: 10px" type="text" required/>
                            </div>
                        </div>
                        <!-- <div class="form-group">
                            <div class="controls col-md-offset-4 col-md-8 ">
                                <div id="div_id_terms" class="checkbox required">
                                    <label for="id_terms" class=" requiredField">
                                         <input class="input-ms checkboxinput" id="id_terms" name="terms" style="margin-bottom: 10px" type="checkbox" />
                                         Agree with the terms and conditions
                                    </label>
                                </div>

                            </div>
                        </div> -->
                        <div class="form-group">
                            <div class="aab controls col-md-4 "></div>
                            <div class="controls col-md-8 ">
                                <input type="submit" name="submit" value="ADD" class="btn btn-primary btn btn-info" id="submit-id-signup" />
                                <!-- or <input type="button" name="Signup" value="Sign Up with Facebook" class="btn btn btn-primary" id="button-id-signup" /> -->
                                &nbsp &nbsp &nbsp &nbsp &nbsp 
                                <a href="../homepage/home.html">HOME</a>
                            </div>
                        </div>

                    </form>

                </form>
            </div>
        </div>
    </div>
</div>






</div>
  </body>
</html>
