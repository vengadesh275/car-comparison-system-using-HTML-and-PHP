
<script type="text/javascript">

if ( window.history.replaceState ) {
    window.history.replaceState( null, null, window.location.href );
}
</script>



<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "memory";

$car1=$_POST['car1'];
$car2=$_POST['car2'];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// $sql = "SELECT a1,a11,a10,a12,a9 FROM addcars WHERE a3='".$user."'";
$sql1 = "SELECT * FROM addcars WHERE a3='".$car1."'";

$result = mysqli_query($conn, $sql1);

if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    $insu=$row["a2"];
    $cname=$row["a3"];
    $cmodel=$row["a4"];
    $cman=$row["a5"];
    $cprice=$row["a6"];
    $ceng=$row["a8"];
    $cgear=$row["a9"];
    $chp=$row["a10"];
    $cfuel=$row["a11"];
    $cacc=$row["a12"];

  }
} else {
  echo "0 results";
}

?>











<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title></title>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!--- Include the above in your HEAD tag ---------->
<style>

  body,html{
  height: 100%;
  width: 100%;
  margin: 0;
  padding: 0;
  background: #e74c3c !important;
  }



  .split {
  height: 100%;
  width: 50%;
  position: fixed;
  z-index: 1;
  top: 0;
  overflow-x: hidden;
  padding-top: 20px;
}

.left {
  left: 0;
  background-color:white;
}

.right {
  right: 0;
  background-color:lightblue;
}

.centered {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
}



  .searchbar{
  margin-bottom: auto;
  margin-top: auto;
  height: 60px;
  background-color: #353b48;
  border-radius: 30px;
  padding: 10px;
  }

  .search_input{
  color: white;
  border: 0;
  outline: 0;
  background: none;
  width: 0;
  caret-color:transparent;
  line-height: 40px;
  transition: width 0.4s linear;
  }

  .searchbar:hover > .search_input{
  padding: 0 10px;
  width: 450px;
  caret-color:red;
  transition: width 0.4s linear;
  }

  .searchbar:hover > .search_icon{
  background: white;
  color: #e74c3c;
  }

  .search_icon{
  height: 40px;
  width: 40px;
  float: right;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
  color:white;
  }
</style>
</head>
<body>

<!DOCTYPE html>
<html>
<head>
  <title>Awesome Search Box</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
</head>
 
<body>
  <form method="POST"  name="forname" action="">

<div class="split left">
  <div class="centered">


     


        <!-- <a href="#" class="search_icon"><i class="fas fa-search"></i></a> -->
        <p><b>Car Name: &nbsp  &nbsp</b><?php echo   $cname ?> </p><br>
        <p><b>Car Model:  &nbsp &nbsp</b> <?php echo   $cmodel ?></p><br>
        <p><b>Manufacturer : &nbsp &nbsp</b><?php echo   $cman ?></p><br>
        <p><b>Gear Type:  &nbsp &nbsp</b><?php echo   $cgear ?></p><br>
        <p><b>Engine Type:  &nbsp &nbsp</b><?php echo   $ceng ?></p><br>
        <p><b>Horse Power: &nbsp &nbsp</b><?php echo   $chp ?></p><br>
        <p><b>Fuel Capacity : &nbsp &nbsp</b><?php echo   $cfuel ?></p><br>
        <p><b>Insurance Type: &nbsp &nbsp</b><?php echo   $insu ?></p><br>
        <p><b>Accessories : &nbsp &nbsp</b><?php echo   $cacc ?></p><br>
        <p><b>Price : &nbsp &nbsp</b><?php echo   $cprice ?></p><br>
        <br>
        <br>
   
        <a href="../homepage/home.html">HOME</a>

      </div>
    </div>
  </div>
</div>
</div>

<?php

$sql2 = "SELECT * FROM addcars WHERE a3='".$car2."'";

$result = mysqli_query($conn, $sql2);

if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    $insu=$row["a2"];
    $cname=$row["a3"];
    $cmodel=$row["a4"];
    $cman=$row["a5"];
    $cprice=$row["a6"];
    $ceng=$row["a8"];
    $cgear=$row["a9"];
    $chp=$row["a10"];
    $cfuel=$row["a11"];
    $cacc=$row["a12"];
    
  }
} else {
  echo "0 results";
}

mysqli_close($conn);

?>

<div class="split right">
  <div class="centered">


        <br>
        <p><b>Car Name: &nbsp  &nbsp</b><?php echo   $cname ?> </p><br>
        <p><b>Car Model:  &nbsp &nbsp</b> <?php echo   $cmodel ?></p><br>
        <p><b>Manufacturer : &nbsp &nbsp</b><?php echo   $cman ?></p><br>
        <p><b>Gear Type:  &nbsp &nbsp</b><?php echo   $cgear ?></p><br>
        <p><b>Engine Type:  &nbsp &nbsp</b><?php echo   $ceng ?></p><br>
        <p><b>Horse Power: &nbsp &nbsp</b><?php echo   $chp ?></p><br>
        <p><b>Fuel Capacity : &nbsp &nbsp</b><?php echo   $cfuel ?></p><br>
        <p><b>Insurance Type: &nbsp &nbsp</b><?php echo   $insu ?></p><br>
        <p><b>Accessories : &nbsp &nbsp</b><?php echo   $cacc ?></p><br>
        <p><b>Price : &nbsp &nbsp</b><?php echo   $cprice ?></p><br>
        <br>
        <br>
   
        <a href="../homepage/home.html">HOME</a>

      </div>
    </div>
  </div>
</div>
</div>

      </form>
        </body>
</html>

</body>
</html>
