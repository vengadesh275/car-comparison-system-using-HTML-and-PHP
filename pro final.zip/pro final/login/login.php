<?php
// $servername = "localhost:3306";
// $username = "root";
// $password = "root";
// $dbname=    "memory";
$uname=$_POST['uname'];
$psw=$_POST['psw'];
// Create connection
$conn = mysqli_connect("localhost:3306", "root","root","memory");
// Check connection
if (!$conn) {
    die("Connection failed: ".mysqli_connect_error());
}
$query = mysqli_query($conn,"SELECT * FROM signup WHERE uname='$uname' AND psw='$psw'");
$rows = mysqli_num_rows($query);
if ($rows == 1) {
header("location:compare.html"); 
} else {
$error = "Username or Password is invalid";
echo "<script type='text/javascript'>alert('$error');</script>";
}
?>