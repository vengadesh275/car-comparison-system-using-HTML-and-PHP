<?php
// $servername = "localhost";
// $username = "root";
// $password = "root";
// $dbname   = "memory";
$uname=$_POST['uname'];
$email=$_POST['email'];
$psw=$_POST['psw'];
// Create connection
$con = mysqli_connect ("localhost","root","root","memory");
// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql="INSERT INTO signup values('$uname','$email','$psw')";
$result=mysqli_query($con,$sql);
if($result)
header("Location:login.html");
else
 echo "Error: " . $sql . "<br>" . mysqli_error($con)
?>