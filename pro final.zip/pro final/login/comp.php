<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "memory";
$suid="";
$suna="";
  $suap="";
    $sucg="";
    $ph="";
if(isset($_POST["submit"])){
$user=$_POST['user'];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// $sql = "SELECT a1,a11,a10,a12,a9 FROM addcars WHERE a3='".$user."'";
$sql = "SELECT * FROM addcars WHERE a3='".$user."'";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    $suid=$row["a1"];
      $suna=$row["a11"];
        $suap=$row["a10"];
          $sucg=$row["a12"];
          $ph=$row["a9"];

      // echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
  }
} else {
  echo "0 results";
}

mysqli_close($conn);
}
?>
<div class="split right">
  <div class="centered">
      <img src="car1.jpg">

  <div class="container h-100">
    <div class="d-flex justify-content-center h-100">
      <div class="searchbar">
        <input class="search_input" type="text" name="user" placeholder="Search...">

          <button class="search_icon" type="submit" name="submit"><i class="fas fa-search"></i></button>


        <!-- <a href="#" class="search_icon"><i class="fas fa-search"></i></a> -->
        <br>
        <br>
        <br>
        <p><b>CAR MODEL: &nbsp  &nbsp</b><?php echo   $suid ?> </p>
        <p><b>PRICE:  &nbsp &nbsp</b> <?php echo   $suna ?></p>
        <p><b>ENGINE TYPE: &nbsp &nbsp</b><?php echo   $suap ?></p>
        <p><b>GEARTYPE:  &nbsp &nbsp</b><?php echo   $sucg ?></p>
        <p><b>FUEL CAPACITY:  &nbsp &nbsp</b><?php echo   $ph ?></p>
        <br>
        <br>
   
        <a href="index.html">HOME</a>

      </div>
    </div>
  </div>
</div>
</div>